## Week 13 Lab: Detecting adaptive genetic variation using multivariate methods ##
# Brenna Forester & Stephanie Manel


# Load libraries:
library(pcadapt)
source("https://bioconductor.org/biocLite.R")
biocLite("qvalue")
library(qvalue)
library(vegan)


setwd("path/to/your/files")

# Data set where dispersal = 15% of the surface:
dat <- read.csv("D15data.csv", check.names=F)
dim(dat)

# Look at the first few rows and columns:
dat[1:5,1:9]

env  <- dat[,1:3]    # Just the environmental variables
snps <- dat[,4:103]  # Just the SNPs
names(snps)          # Locus 0 is under selection
    
  
######################
## PCA with pcadapt ##
######################

K <- 10 
x <- pcadapt(data=snps, K=K) 
plot(x, option="screeplot")  # No obvious plateau; 5 is reasonable K 

K<-5
x <- pcadapt(data=snps, K=K) 

summary(x)    # Numerical quantities obtained after performing a PCA
?pcadapt      # Provides information on the summary statistics 

plot(x,option="manhattan") # -log10(p-value) for each SNP
plot(x,option="stat.distribution") # Distribution of scaled Mahalanobis plot
hist(x$pvalues, xlab="p-values", main=NULL)

?qvalue      
qval <- qvalue(x$pvalues)$qvalues
qval 
alpha <- 0.1

# List of candidate SNPs for an expected FDR lower than 10%
outliers <- which(qval<alpha) 
print(outliers)
length(outliers)


# Logistic regression:

mod0 <- glm(cbind(snps$"0",2-snps$"0")~env$habitat,family=binomial)
summary(mod0)


#########
## RDA ##
#########

snp.rda <- rda(snps, env, scale=T)  # This is equivalent to snps~env
plot(snp.rda, scaling=1)            # Plot the RDA

source("rda_outliers.R")
rda.outliers <- rda.out(snp.rda=snp.rda, rda.sd=3)
rda.outliers
