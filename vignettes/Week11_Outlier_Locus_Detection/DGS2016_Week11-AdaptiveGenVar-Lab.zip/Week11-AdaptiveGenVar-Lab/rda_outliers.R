# Function to check for outliers on three constrained RDA axes (# for simulation study)
    # where snp.rda = the rda object, and
    # sd is the number of standard deviations from the mean to test (default = 3)

rda.out <- function(snp.rda, rda.sd=3){ 
  
  snp.rda.sum <- summary(snp.rda)           # summary information
  snpload.rda <- snp.rda.sum$species[,1:3]  # pull SNP loadings on each of the three constrained axes

    for (i in 1:3) {        # 3 runs of the loop, one for each constrained axis                              
        x <- snpload.rda
        x <- matrix(unlist(x), ncol=dim(x)[2])
        rownames(x) <- colnames(snps)
        x <- x[,i]
  
        # Calculate mean SNP loading on the axis +/- # of standard deviations set above
        lims <- mean(x) + c(-1, 1) * rda.sd * sd(x)   
        out <- x[x < lims[1] | x > lims[2]]  # pull loci with loadings beyond 3 sd
  
        # Format the outlier loci   
        if (length(out) > 0) {
        names <- as.numeric(names(out))                    
        axis <- rep(i, length(out))
        outdat <- t(rbind(axis, names, as.numeric(out)))
    
        # Correlations between outliers and environmental predictors:      
        snpcors <- matrix(NA, nrow=length(names), ncol=6)
    
        for (j in 1:length(names)) {
        outlocus <- names[j] + 1   # to access correct column in snp datframe
        outsnp <- snps[,outlocus]
      
        corr.x <- cor.test(outsnp, env[,1])
        snpcors[j,1] <- corr.x$estimate
        snpcors[j,2] <- corr.x$p.value
      
        corr.y <- cor.test(outsnp, env[,2])
        snpcors[j,3] <- corr.y$estimate
        snpcors[j,4] <- corr.y$p.value
      
        corr.h <- cor.test(outsnp, env[,3])
        snpcors[j,5] <- corr.h$estimate
        snpcors[j,6] <- corr.h$p.value
        }
    
    outdat <- cbind(outdat, snpcors)
    fname <- paste("rda", i, sep="")
    assign(fname, outdat)
  }
  else if (length(out) == 0) {
    fname <- paste("rda", i, sep="")
    assign(fname, NA)
  }
}

out.rda <- rbind(rda1, rda2, rda3)
out.rda <- as.data.frame(out.rda)
out.rda <- out.rda[complete.cases(out.rda),]
colnames(out.rda) <- c("axis","locus","loading", "x-corr", "x-pval", "y-corr", "y-pval", "h-corr", "h-pval")
rownames(out.rda) <- NULL
return(out.rda)
}